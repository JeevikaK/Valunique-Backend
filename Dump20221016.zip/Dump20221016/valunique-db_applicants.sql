-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: valunique-server.mysql.database.azure.com    Database: valunique-db
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicants`
--

DROP TABLE IF EXISTS `applicants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidateID` int NOT NULL,
  `jobID` varchar(8) NOT NULL,
  `jobName` varchar(50) DEFAULT NULL,
  `status` enum('Applying','Applied','Rejected','Shortlisted') DEFAULT NULL,
  `whyVolvo` varchar(255) DEFAULT NULL,
  `aboutVolvo` varchar(255) DEFAULT NULL,
  `skills` varchar(255) DEFAULT NULL,
  `additionalSkills` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `relocate` varchar(255) DEFAULT NULL,
  `appliedOn` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` VALUES (27,12345678,'1B2A5676','Businesss Analyst','Shortlisted','Volvo is a great company','That it\'s a great company','Java, Communication','bootstrap','Algeria','yes','2022-09-25'),(28,12345678,'1B2A5679','Android Project Manager','Applied','asdas','sadasd','Marketting, Kotlin','','Albania','yes','2022-09-25'),(29,12345677,'1B2A5679','Android Project Manager','Applied','asdasd','asdasd','Communication, Flutter','','Albania','yes','2022-09-25'),(30,12345678,'1B2A5677','Junior Seibel Developer','Applied','simply','nothing','Python, Flutter','bootstrap, c++','Bahamas','yes','2022-09-25'),(31,12345676,'1B2A5679','Android Project Manager','Applied','asdasdasd','asdas','Communication, Flutter','','Albania','yes','2022-09-25'),(32,12345677,'1B2A5676','Businesss Analyst','Rejected','no idea','it is a great company','Python, Communication','bootstrap, c','India','no','2022-09-25'),(33,12345678,'1B2A5678','Senior Seibel Developer','Applied','asdasdas','dasdasd','Java, MongoDB, Docker','python, reading','Åland Islands','yes','2022-09-25'),(34,12345676,'1B2A5676','Businesss Analyst','Applied','I\'m an intern','It is a great company','Python, Communication','','Afghanistan','yes','2022-09-25'),(35,12345679,'1B2A5678','Senior Seibel Developer','Applied','asdsdas','sadasd','Java, MongoDB, Git','','Bangladesh','yes','2022-09-25'),(36,12345678,'1B2A5672','Quality Assurance','Applied','Test Data','TESTING\r\n\r\n\r\nfdsfsd sfsd \r\nd dsf ds\r\n\r\nsdf sd\r\nf d\r\n df\r\nfds\r\nds\r\ndsfd\r\nsfds\r\n','FunctionalTesting, ManualTesting','','India','yes','2022-09-25'),(37,12345675,'1B2A5678','Senior Seibel Developer','Shortlisted','sdfsdfs','sdfdsfdsf','Java, MongoDB, Git','','Albania','yes','2022-10-06'),(49,12345675,'1B2A5676','Businesss Analyst','Applied','awsdaw','asdas','Java, Marketting','','Albania','yes','2022-10-09'),(51,12345678,'1B2A5681','DOT NET  Developer','Applying','asdfghj','hahjsajk','Python, Flutter','','India','no','2022-10-10');
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-16 13:53:57
